#include <foo.h>/* comment */
#include "guard.h"// comment
