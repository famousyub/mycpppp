#pragma once

int foo() { return 42; }
