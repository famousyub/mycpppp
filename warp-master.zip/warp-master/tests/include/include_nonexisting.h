#include "once.h"
#include "include_doesnotexist.h"
#if 0
# define something
#endif
