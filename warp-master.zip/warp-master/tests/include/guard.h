#ifndef GUARD_H
#define GUARD_H

int foo() { return 42; }

#endif /* ndef GUARD_H */
